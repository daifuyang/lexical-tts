export default {
  paragraph: "editor-paragraph",
  pinyin: "editor-pinyin",
  number: "editor-number",
};
