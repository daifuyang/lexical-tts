// 主播插件

import { useLexicalComposerContext } from "@lexical/react/LexicalComposerContext";
import {
  $getSelection,
  $isElementNode,
  $isNodeSelection,
  $isRangeSelection,
  $isTextNode,
  COMMAND_PRIORITY_EDITOR,
  ElementNode,
  LexicalCommand,
  createCommand
} from "lexical";

import { useEffect } from "react";
import { $createVoiceNode, $isVoiceNode, VoiceNode, $getAncestor } from "../nodes/VoiceNode";

interface Payload {
  data: {
    voice: string;
  };
}

export const ADD_VOICE_COMMAND: LexicalCommand<Payload> = createCommand("ADD_VOICE_COMMAND");

export default function VoicePlugin(props: any) {
  const [editor] = useLexicalComposerContext();
  useEffect(() => {
    if (!editor.hasNodes([VoiceNode])) {
      throw new Error("VoicePlugin: VoiceNode not registered on editor (initialConfig.nodes)");
    }
    return editor.registerCommand(
      ADD_VOICE_COMMAND,
      (payload: Payload) => {

        const voice = payload.data

        const selection = $getSelection();
        if (!$isRangeSelection(selection)) {
          return false;
        }

        const nodes = selection.extract();

        // 先删除旧的
        nodes.forEach((node) => {
          const parent = node.getParent();
          if ($isVoiceNode(parent)) {
            const children = parent.getChildren();
            for (let i = 0; i < children.length; i++) {
              parent.insertBefore(children[i]);
            }
            parent.remove();
          }
        });

        if (nodes.length === 1) {
          const firstNode = nodes[0];
          // 如果第一个节点是voice或者父节点是voice,那我们就更新他
          const voiceNode = $getAncestor(firstNode, $isVoiceNode);
          if (voiceNode) {
            return false;
          }
        }

        let prevParent: ElementNode | VoiceNode | null = null;
        let voiceNode: VoiceNode | null = null;

        nodes.forEach((node) => {
          const parent = node.getParent();
          if (
            parent === VoiceNode ||
            parent === null ||
            ($isElementNode(node) && !node.isInline())
          ) {
            return false;
          }

          if ($isVoiceNode(parent)) {
            // 修改父元素
            voiceNode = parent;
            return false;
          }

          if (!parent.is(prevParent)) {
            prevParent = parent;
            voiceNode = $createVoiceNode(voice);
            if ($isVoiceNode(parent)) {
              if (node.getPreviousSibling() === null) {
                parent.insertBefore(voiceNode);
              } else {
                parent.insertAfter(voiceNode);
              }
            } else {
              node.insertBefore(voiceNode);
            }
          }

          if ($isVoiceNode(node)) {
            if (node.is(voiceNode)) {
              return false;
            }
            if (voiceNode !== null) {
              const children = node.getChildren();
              for (let i = 0; i < children.length; i++) {
                voiceNode.append(children[i]);
              }
            }
            node.remove();
            return false;
          }

          if (voiceNode !== null) {
            voiceNode.append(node);
          }
        });


        return true;
      },
      COMMAND_PRIORITY_EDITOR
    );
  }, [editor]);

  return null;
}
